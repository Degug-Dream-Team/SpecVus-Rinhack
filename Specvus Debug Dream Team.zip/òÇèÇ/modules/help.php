<!-- Module -->
<div class="row">
	<div class="col s12">
		<h3>Command list</h3>
		<pre><?php $d0->virsh_passthru('help');?></pre>
	</div>
</div>